﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace OnlineRecruitmentSystem_Employer_.Models
{
    public class UserLoginInfo
    {


            [DisplayName("Username")]
            public string uname { get; set; }

            [DisplayName("Password")]
            public string pwd { get; set; }

            [DisplayName("User Type")]
            public string userType { get; set; }

    }

}
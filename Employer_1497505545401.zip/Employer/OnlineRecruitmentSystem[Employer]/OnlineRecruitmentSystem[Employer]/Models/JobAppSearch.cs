﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineRecruitmentSystem_Employer_.Models
{
    public class JobAppSearch
    {
        [DisplayName("Technology")]
        public string Technology { get; set; }
        
        [Range(0,30,ErrorMessage = "Provide a Valid experience")]
        [DisplayName("Experience")]
        public int experience { get; set; }
        [DisplayName("Preferred Location")]
        public string PreferredLocation { get; set; }
        public int criteria { get; set; }

    }

}
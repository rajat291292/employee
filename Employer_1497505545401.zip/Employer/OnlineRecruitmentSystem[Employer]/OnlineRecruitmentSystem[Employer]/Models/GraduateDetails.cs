﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineRecruitmentSystem_Employer_.Models
{
    public class GraduateDetails
    {
        [Required]
        [DisplayName("User Name")]
        public string userName { get; set; }
        [Required]
        [DisplayName("Degree")]
        public string degree { get; set; }
        [Required]
        [Range(35, 100, ErrorMessage = "Provide a Valid Percentage")]
        [DisplayName("Degree Percentage")]
        public decimal degreePercentage { get; set; }
        [Required]
        [Range(35, 100, ErrorMessage = "Provide a Valid Percentage")]
        [DisplayName("Intermediate Percentage")]
        public decimal intermediatePercentage { get; set; }
        [Required]
        [Range(35, 100, ErrorMessage = "Provide a Valid Percentage")]
        [DisplayName("Tenth Percentage")]
        public decimal tenthPercentage { get; set; }
        [Required]
        [DisplayName("Mobile")]
        [StringLength(10)]
        [RegularExpression("[7-9]{1}\\d{9}", ErrorMessage = "Provide a valid 10 digit mobile number")]
        public string mobile { get; set; }
        [DisplayName("Technology")]
        [Required]
        public string technology { get; set; }
        [DisplayName("Preferred Location")]
        [Required]
        public string preferredLocation { get; set; }

        [Range(0, 30, ErrorMessage = "Provide a Valid experience")]
        [DisplayName("Experience")]
        [Required]
        public int experience { get; set; }

    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineRecruitmentSystem_Employer_.Models
{
    public class JobApplication
    {
        [DisplayName("ApplicantId")]
        public string applicantId { get; set; }
        [DisplayName("User Name")]
        public string userName { get; set; }

        [Required]
        [DisplayName("Degree")]
        public string degree { get; set; }
        [Range(35, 100, ErrorMessage = "Provide a Valid Percentage")]
        [Required]
        [DisplayName("Degree Percentage")]
        public decimal degreePercentage { get; set; }
        [Range(35, 100, ErrorMessage = "Provide a Valid Percentage")]
        [Required]
        [DisplayName("Intermediate Percentage")]
        public decimal intermediatePercentage { get; set; }
        [Range(35, 100, ErrorMessage = "Provide a Valid Percentage")]
        [Required]
        [DisplayName("Tenth Percentage")]
        public decimal tenthPercentage { get; set; }
        [Required]
        [DisplayName("Mobile")]
        [StringLength(10)]
        [RegularExpression("[7-9]{1}\\d{9}", ErrorMessage = "Provide a valid 10 digit mobile number")]
        public string mobile { get; set; }
        [Required]
        [DisplayName("Technology")]
        public string technology { get; set; }
        [Required]
        [DisplayName("Preferred Location")]
        public string preferredLocation { get; set; }
        [Required]
        [Range(0, 30, ErrorMessage = "Provide a Valid Experience")]
        [DisplayName("Experience")]

        public int experience { get; set; }
        [DisplayName("JobTitle")]
        public string JobTitle { get; set; }
        [DisplayName("JobId")]
        public int JobId { get; set; }
        [DisplayName("Application Status")]
        public string ApplicationStatus { get; set; }


    }
}
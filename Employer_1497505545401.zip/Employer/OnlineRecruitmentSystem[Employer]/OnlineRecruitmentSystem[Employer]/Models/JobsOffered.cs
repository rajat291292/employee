﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineRecruitmentSystem_Employer_.Models
{
    public class JobsOffered
    {
        [Required]
        [DisplayName("JobTitle")]
        public string JobTitle { get; set; }
        [Required]
        [DisplayName("Location")]
        public string JobLocation { get; set; }
        [Required]
        [DisplayName("Qualification")]
        public string Qualification { get; set; }

        [Required]
        [DisplayName("Experience")]
        [Range(0, 30, ErrorMessage = "Provide a Valid experience")]
        public int Experience { get; set; }
        [DisplayName("JobId")]
        public int JobId { get; set; }

        [DisplayName("Employer Name")]
        public string EmployerName { get; set; }

    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineRecruitmentSystem_Employer_.Models
{
    public class UserPassword
    {

        [DisplayName("Username")]
        public string Username { get; set; }
        [DisplayName("Password")]
        [Required]
        public string Password { get; set; }
        [DisplayName("Userype")]
        [Required]
        public int uType { get; set; }
        [Required]
        [Compare("Password", ErrorMessage = "Password & Confirm Password Doesn't match")]
        public string ConfirmPassword { get; set; }


    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineRecruitmentSystem_Employer_.Models
{
    public class UserDetails
    {
        [Required]
        [DisplayName("UserType")]
        public int Usertype { get; set; }

        [Required]
        [DisplayName("User Name")]
        public string Username { get; set; }
        [Required]
        [DisplayName("Mobile")]
        [StringLength(10)]
        [RegularExpression("[7-9]{1}\\d{9}", ErrorMessage = "Provide a valid 10 digit mobile number")]
        public string mobile { get; set; }
        [Required]
        [DisplayName("Gender")]
        public string gender { get; set; }
        [Required]
        [DisplayName("Email-Id")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Please enter a valid e-mail adress")]
        public string email { get; set; }
    }
}
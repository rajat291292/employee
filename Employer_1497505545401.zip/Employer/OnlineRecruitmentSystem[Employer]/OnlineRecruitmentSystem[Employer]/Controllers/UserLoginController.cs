﻿using OnlineRecruitmentSystem_Employer_.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace OnlineRecruitmentSystem_Employer_.Controllers
{
    public class UserLoginController : Controller
    {
        //
        // GET: /UserLogin/
        public ActionResult Index()
        {
            return View();
     
        }
        [HttpGet]
        public ActionResult CheckUser()
    {
        return View();
    }
     
        [HttpPost]
        public ActionResult CheckUser(UserLoginInfo user)
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter result = new ObjectParameter("res", typeof(Int32));
                dbObject.uspCheckUser(user.uname, user.pwd, Convert.ToInt32(user.userType), result);
                var res = result.Value.ToString();
                int finalResult = Convert.ToInt32(res);
                if (finalResult > 0)
                {
                    Session["loginId"] = user.uname;
                    if (user.userType == "1001")
                    {
                        return RedirectToAction("Index", "Admin");
                    }
                    else if (user.userType == "1002")
                    {
                        return RedirectToAction("Index", "Employer");
                    }
                    else if(user.userType == "1003")
                    {
                        return RedirectToAction("Index", "Graduate");
                    }
                    return View();
                }
                else
                {
                    MessageBox.Show("Invalid Credentials");
                    return RedirectToAction("CheckUser", "UserLogin");

                }
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        public ActionResult Logout()
        {
            if (Session["loginId"] == null)
            {
                MessageBox.Show("You are not logged in please login");
                return RedirectToAction("Index", "UserLogin");
            }
            else
            {
                Session.RemoveAll();
                return RedirectToAction("Index", "UserLogin");
            }
        }

       [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

       [HttpPost]
       public ActionResult Register(UserDetails newuser)
       {
           if (ModelState.IsValid)
           {
               OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
               ObjectParameter logId = new ObjectParameter("loginId", typeof(string));
               ObjectParameter result = new ObjectParameter("res", typeof(string));
               dbObject.uspRegisterUser(logId, newuser.Username, newuser.gender, newuser.mobile, newuser.Usertype, newuser.email, result);
               var res = result.Value.ToString();
               int finalResult = Convert.ToInt32(res);
               if (finalResult > 0)
               {
                   MessageBox.Show("Your Login Id is" + logId.Value);
                   Session["loginId"] = logId.Value;
                   TempData["loginId"] = logId.Value; 
                  
                   Session["uType"] = newuser.Usertype;

                   if (Session["uType"].ToString() == "1002")
                   {
                       return RedirectToAction("SavePassword", "Employer");
                   }
                   else
                       return RedirectToAction("SavePassword", "Graduate");
               }
               else
               {
                   MessageBox.Show("Invalid Credentials");
                   return RedirectToAction("CheckUser", "UserLogin");

               }
           }
           else
           {
               return View();
           }
       }
       


        }
	}

﻿using OnlineRecruitmentSystem_Employer_.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace OnlineRecruitmentSystem_Employer_.Controllers
{
    public class AdminController : Controller
    {
        //
        // GET: /Admin/
        public ActionResult Index()
        {
            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            ObjectParameter userName = new ObjectParameter("uname", typeof(string));
            dbObject.uspGetUserName(Session["loginId"].ToString(), userName);

            Session["username"] = userName.Value;
            return View();
        }
        [HttpGet]
        public ActionResult ViewAllUsers()
        {


            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            var res = dbObject.uspViewAllUserDetails();
            List<AllUserDetails> userList = new List<AllUserDetails>();
            foreach (var item in res)
            {
                AllUserDetails user = new AllUserDetails();
                user.UserId = item.loginId;
                user.Username = item.userName;
                user.Usertype = item.userType;
                user.mobile = item.mobile;
                user.email = item.email;
                userList.Add(user);
            }
            return View(userList);
        }
        public ActionResult Logout()
        {
            if (Session["loginId"] == null)
            {
                MessageBox.Show("You are not logged in please login");
                return RedirectToAction("Index", "UserLogin");
            }
            else
            {
                Session.RemoveAll();
                return RedirectToAction("Index", "UserLogin");
            }
        }
        [HttpGet]
        public ActionResult Delete(string id)
        {
            DialogResult dr = MessageBox.Show("Warning! You are About to Delete a Job!! \n Are you Sure?", "Warning", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {

                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter result = new ObjectParameter("res", typeof(Int32));
                dbObject.uspDeleteUser(id, result);
                var res = result.Value;
                if ((int)res > 0)
                {
                    MessageBox.Show("User deleted");
                    return RedirectToAction("ViewAllUsers");
                }
                else
                {
                    MessageBox.Show("User not deleted");
                    return RedirectToAction("ViewAllUsers");
                }
            }
            else
            {
                return RedirectToAction("ViewAllUsers");
            }
        }




        [HttpGet]
        public ActionResult SavePassword()
        {
            return View();
        }
        [HttpPost]

        public ActionResult SavePassword(UserPassword pwd)
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter result = new ObjectParameter("res", typeof(string));
                dbObject.uspSavePassword(Session["loginId"].ToString(), pwd.Password, result);
                var res = result.Value.ToString();
                int finalResult = Convert.ToInt32(res);
                if (finalResult > 0)
                {
                    MessageBox.Show("Your Password has been saved");
                    return RedirectToAction("Index");
                }
                else
                {
                    MessageBox.Show("Your Password has not been saved");
                    return RedirectToAction("Index");
                }
            }
            else
            {
                return RedirectToAction("Index");
            }
        }
    }
}
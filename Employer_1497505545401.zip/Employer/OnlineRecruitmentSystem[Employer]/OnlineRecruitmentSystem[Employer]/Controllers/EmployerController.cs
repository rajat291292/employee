﻿using OnlineRecruitmentSystem_Employer_.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace OnlineRecruitmentSystem_Employer_.Controllers
{
    public class EmployerController : Controller
    {
        //
        // GET: /Employer/
        public ActionResult Index()
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter userName = new ObjectParameter("uname", typeof(string));
                dbObject.uspGetUserName(Session["loginId"].ToString(), userName);

                Session["username"] = userName.Value;
                return View();
            }
            else
            {
                return View();
            }
        }
        
        [HttpGet]
        public ActionResult SavePassword()
        {
            return View();
        }


        public ActionResult Logout()
        {
            if (Session["loginId"] == null)
            {
                MessageBox.Show("You are not logged in please login");
                return RedirectToAction("Index", "UserLogin");
            }
            else
            {
                Session.RemoveAll();
                return RedirectToAction("Index", "UserLogin");
            }
        }



        [HttpPost]

        public ActionResult SavePassword(UserPassword pwd)
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter result = new ObjectParameter("res", typeof(string));
                //string id = Session["loginId"].ToString();
                string newid = TempData["loginId"].ToString();

                //  MessageBox.Show("id is" + id);

                dbObject.uspSavePassword(TempData["loginId"].ToString(), pwd.Password, result);
                var res = result.Value.ToString();
                int finalResult = Convert.ToInt32(res);
                if (finalResult > 0)
                {
                    MessageBox.Show("Your Password has been saved");
                    return RedirectToAction("EmployerHomepage", "Employer");
                }
                else
                {
                    MessageBox.Show("Your Password has not been saved");
                    return RedirectToAction("Index");
                }
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        public ActionResult EmployerHomepage()
        {
            if (ModelState.IsValid)
            {

                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter userName = new ObjectParameter("uname", typeof(string));
                dbObject.uspGetUserName(Session["loginId"].ToString(), userName);
                //Session["loginId"] = TempData["loginId"];
                Session["username"] = userName.Value;
                return View();
            }
            else
            {
                return View();
            }

        }

        [HttpGet]
        public ActionResult AddNewJob()
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter userName = new ObjectParameter("uname", typeof(string));
                dbObject.uspGetUserName(Session["loginId"].ToString(), userName);

                return View();
            }
            else
            {
                return View();
            }
        }
        [HttpPost]
        public ActionResult AddNewJob(JobsOffered newJob)
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter result = new ObjectParameter("res", typeof(Int32));
                dbObject.uspAddNewJob(newJob.JobTitle, Session["loginId"].ToString(), Session["username"].ToString(), newJob.Experience, newJob.JobLocation, newJob.Qualification, result);
                var finalResult = result.Value;
                if ((int)finalResult > 0)
                {
                    MessageBox.Show("Job Added");
                    return RedirectToAction("ViewAllJobApplication");
                }
                else
                {
                    MessageBox.Show("Job not Added");
                    return RedirectToAction("AddNewJob");
                }
            }
            else
            {
                return RedirectToAction("EmployerHomepage");
            }
        }


        public ActionResult ViewAllJobApplication()
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                var jobList = dbObject.uspViewAllJobApplication(Session["loginId"].ToString());
                List<JobsOffered> jobsList = new List<JobsOffered>();
                if (jobList != null)
                {
                    foreach (var item in jobList)
                    {
                        JobsOffered job = new JobsOffered();
                        job.Experience = (int)item.experience;
                        job.JobLocation = item.jobLocation;
                        job.JobTitle = item.jobTitle;
                        job.Qualification = item.qualification;
                        job.JobId = item.jobId;
                        jobsList.Add(job);
                    }

                    return View(jobsList);
                }
                else
                {
                    MessageBox.Show("You have not added any Jobs!!!! Please add a New Job");
                    return RedirectToAction("AddNewJob");
                }
            }
            else
            {
                return RedirectToAction("EmployerHomepage");
            }

        }
        [HttpGet]
        public ActionResult Details(int id)
        {
            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            JobsOffered job = new JobsOffered();
            var jobFound = dbObject.uspViewOneJob(id);
            foreach (var item in jobFound)
            {
                job.JobId = item.jobId;
                job.JobLocation = item.jobLocation;
                job.Experience = (int)item.experience;
                job.JobTitle = item.jobTitle;
                job.Qualification = item.qualification;

            }



            return View(job);
        }


        public ActionResult ViewAllJobApplicationForm()
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                var jobAppList = dbObject.uspViewAllJobApplicationForms(Session["loginId"].ToString());
                List<JobApplication> jobApplicationList = new List<JobApplication>();

                foreach (var item in jobAppList)
                {
                    JobApplication jobApp = new JobApplication();
                    jobApp.userName = item.applicantName;
                    jobApp.degree = item.degree;
                    jobApp.degreePercentage = (decimal)item.degreePercentage;
                    jobApp.intermediatePercentage = (decimal)item.intermediatePercentage;
                    jobApp.tenthPercentage = (decimal)item.tenthPercentage;
                    jobApp.mobile = item.mobile;
                    jobApp.preferredLocation = item.preferredLocation;
                    jobApp.experience = (int)item.experience;
                    jobApp.technology = item.technology;
                    jobApp.applicantId = item.applicationId;
                    jobApplicationList.Add(jobApp);

                }
                return View(jobApplicationList);
            }
            else
            {
                return View();
            }
        }

        [HttpGet]
        public ActionResult JobAppDisplay(List<JobApplication> job)
        {

            var jobList = TempData["appList"];

            return View(jobList);
        }

        [HttpGet]
        public ActionResult ViewMyDetails()
        {
            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            var res = dbObject.uspViewEmployerdetails(Session["loginId"].ToString());
          
                foreach(var item in res)
                {
                    EmployerDetails emp = new EmployerDetails();
                    emp.userName = item.UsernameName;
                    emp.mobile = item.mobile;
                    emp.gender = item.Gender;
                    emp.dateofbirth = item.DateofBirth;
                    emp.email = item.email;
                    emp.id = (int)item.id;
                    return View(emp);
                }
        
                MessageBox.Show("You have not saved your details Save your details");
                return RedirectToAction("SaveMyDetails");
          
        }

        [HttpGet]
        public ActionResult SaveMyDetails()
        {
            return View();
        }
        [HttpPost]
        public ActionResult SaveMyDetails(EmployerDetails emp)
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter result = new ObjectParameter("res", typeof(Int32));
                dbObject.uspSavedEmployerDetails(emp.userName, emp.dateofbirth, emp.gender, emp.mobile, emp.email, Session["loginId"].ToString(), result);
                var res = result.Value;
                if ((int)res > 0)
                {
                    MessageBox.Show("Your details has been saved");
                    return RedirectToAction("EmployerHomePage");

                }
                else
                {
                    MessageBox.Show("Details has not been saved");
                    return RedirectToAction("EmployerHomePage");
                }
            }
            else
            {
                return View();
            }

        }
        [HttpGet]
        public ActionResult UpdateMydetails()
        {
            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            var res = dbObject.uspViewEmployerdetails(Session["loginId"].ToString());
            

            foreach (var item in res)
            {
                EmployerDetails emp = new EmployerDetails();
                emp.userName = item.UsernameName;
                emp.mobile = item.mobile;
                emp.gender = item.Gender;
                emp.dateofbirth = item.DateofBirth;
                emp.email = item.email;
                emp.id = (int)item.id;
                return View(emp);
            }

            MessageBox.Show("You have not saved your details Save your details");
            return RedirectToAction("SaveMyDetails");


        }

        [HttpPost]
        public ActionResult UpdateMydetails(EmployerDetails emp)
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter result = new ObjectParameter("res", typeof(Int32));
                dbObject.uspUpdateEmployerDetails(emp.userName, emp.dateofbirth, emp.gender, emp.mobile, emp.email, Session["loginId"].ToString(), result);
                var res = result.Value;
                if ((int)res > 0)
                {
                    MessageBox.Show("Your details has been saved");
                    return RedirectToAction("EmployerHomePage");

                }
                else
                {
                    MessageBox.Show("Details has not been saved");
                    return RedirectToAction("EmployerHomePage");
                }
            }
            else
            {
                return View();
            }

        }
        [HttpGet]
        public ActionResult Cancel(string applicantId)
        {
            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            ObjectParameter result = new ObjectParameter("res", typeof(Int32));

            dbObject.uspCancelApplication(applicantId, result);
            var res = result.Value;
            if ((int)res > 0)
            {
                MessageBox.Show("The application has been cancelled");
                return RedirectToAction("EmployerHomePage");

            }
            else
            {
                MessageBox.Show("Not Updated");
                return RedirectToAction("EmployerHomePage");
            }


        }




        [HttpGet]
        public ActionResult ApproveForRecruitment(string applicantId)
        {
            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            ObjectParameter result = new ObjectParameter("res", typeof(Int32));

            dbObject.uspUpdateApplication(applicantId, Session["username"].ToString(), result);
            var res = result.Value;
            if ((int)res > 0)
            {
                MessageBox.Show("The application has been Approved");
                return RedirectToAction("EmployerHomePage");

            }
            else
            {
                MessageBox.Show("Not Updated");
                return RedirectToAction("EmployerHomePage");
            }


        }

        [HttpGet]
        public ActionResult SearchJobApplicationForm()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SearchJobApplicationForm(JobAppSearch searchObj)
        {
            if(ModelState.IsValid)
            { 
            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            if (searchObj.criteria == 1)
            {
                if (searchObj.experience == 0 & searchObj.PreferredLocation != null)
                {
                    MessageBox.Show("Keep the experience as well as Preferred Location empty");
                    return View();
                }
                var jobAppList = dbObject.uspSearchJobApplications(searchObj.Technology, null, null, searchObj.criteria, Session["loginId"].ToString());
                List<JobApplication> jobApplicationList = new List<JobApplication>();

                foreach (var item in jobAppList)
                {
                    JobApplication job = new JobApplication();
                    job.applicantId = item.applicationId;

                    job.degree = item.degree;
                    job.degreePercentage = (decimal)item.degreePercentage;
                    job.intermediatePercentage = (decimal)item.intermediatePercentage;
                    job.tenthPercentage = (decimal)item.tenthPercentage;
                    job.experience = (int)item.experience;
                    job.mobile = item.mobile;
                    job.technology = item.technology;
                    job.preferredLocation = item.preferredLocation;
                    job.userName = item.applicantName;
                    jobApplicationList.Add(job);


                }

                if (jobApplicationList.Count == 0)
                {

                    MessageBox.Show("No results were found based your search");
                    return View();

                }
                else
                {
                    TempData["appList"] = jobApplicationList;
                    return RedirectToAction("JobAppDisplay", "Employer", new { job = jobApplicationList });
                }
            
            }
            else if (searchObj.criteria == 2)
            {
                if (searchObj.Technology != null & searchObj.experience == 0)
               {
                    MessageBox.Show("Keep the Technology as well as Experience empty");
                    return View();
                }
                var jobAppList = dbObject.uspSearchJobApplications(null, searchObj.PreferredLocation, null, searchObj.criteria, Session["loginId"].ToString());
                List<JobApplication> jobApplicationList = new List<JobApplication>();
                foreach (var item in jobAppList)
                {
                    JobApplication job = new JobApplication();
                    job.applicantId = item.applicationId;
                    job.degree = item.degree;
                    job.degreePercentage = (decimal)item.degreePercentage;
                    job.intermediatePercentage = (decimal)item.intermediatePercentage;
                    job.tenthPercentage = (decimal)item.tenthPercentage;
                    job.experience = (int)item.experience;
                    job.mobile = item.mobile;
                    job.technology = item.technology;
                    job.preferredLocation = item.preferredLocation;
                    job.userName = item.applicantName;
                    jobApplicationList.Add(job);

                }
                TempData["appList"] = jobApplicationList;
                return RedirectToAction("JobAppDisplay", "Employer", new { job = jobApplicationList });
            }

            else if (searchObj.criteria == 3)
            {
                if (searchObj.Technology != null | searchObj.PreferredLocation != null)
                {
                    MessageBox.Show("Keep the Technology as well as Preferred Location empty");
                    return View();
                }
                var jobAppList = dbObject.uspSearchJobApplications(null, null, searchObj.experience, searchObj.criteria, Session["loginId"].ToString());
                List<JobApplication> jobApplicationList = new List<JobApplication>();
                foreach (var item in jobAppList)
                {
                    JobApplication job = new JobApplication();
                    job.applicantId = item.applicationId;
                    job.degree = item.degree;
                    job.degreePercentage = (decimal)item.degreePercentage;
                    job.intermediatePercentage = (decimal)item.intermediatePercentage;
                    job.tenthPercentage = (decimal)item.tenthPercentage;
                    job.experience = (int)item.experience;
                    job.mobile = item.mobile;
                    job.technology = item.technology;
                    job.preferredLocation = item.preferredLocation;
                    job.userName = item.applicantName;
                    jobApplicationList.Add(job);

                }
                TempData["appList"] = jobApplicationList;
                return RedirectToAction("JobAppDisplay", "Employer", new { job = jobApplicationList });
            }
            else if (searchObj.criteria == 4)
            {
                var jobAppList = dbObject.uspSearchJobApplications(searchObj.Technology, searchObj.PreferredLocation, searchObj.experience, searchObj.criteria, Session["loginId"].ToString());
                List<JobApplication> jobApplicationList = new List<JobApplication>();
                foreach (var item in jobAppList)
                {
                    JobApplication job = new JobApplication();
                    job.applicantId = item.applicationId;
                    job.degree = item.degree;
                    job.degreePercentage = (decimal)item.degreePercentage;
                    job.intermediatePercentage = (decimal)item.intermediatePercentage;
                    job.tenthPercentage = (decimal)item.tenthPercentage;
                    job.experience = (int)item.experience;
                    job.mobile = item.mobile;
                    job.technology = item.technology;
                    job.preferredLocation = item.preferredLocation;
                    job.userName = item.applicantName;
                    jobApplicationList.Add(job);

                }
                TempData["appList"] = jobApplicationList;
                return RedirectToAction("JobAppDisplay", "Employer", new { job = jobApplicationList });

            }
            else
            {
                MessageBox.Show("Please Select the search Options");
                return View();
            }
            }
            else
            {
                return View();
            }

        }






        [HttpGet]
        public ActionResult Delete(int id)
        {

            DialogResult dr = MessageBox.Show("Warning! You are About to Delete a Job!! \n Are you Sure?", "Warning", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                JobsOffered job = new JobsOffered();
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter result = new ObjectParameter("res", typeof(Int32));
                dbObject.uspDeleteJob(id, result);
                var res = result.Value;
                if ((int)res > 0)
                {
                    MessageBox.Show("Job Deleted");
                    return RedirectToAction("ViewAllJobApplication");
                }
                else
                {
                    MessageBox.Show("Job not Deleted");
                    return RedirectToAction("ViewAllJobApplication");
                }
            }

            else
            {

                return RedirectToAction("ViewAllJobApplication");
            }

        }

        [HttpGet]
        public ActionResult EditMyDetails()
        {

            return View();
        }

        [HttpPost]
        public ActionResult EditMyDetails(EmployerDetails emp)
        {
            if (ModelState.IsValid)
            {
                return View(emp);
            }
            else
            {
                return View();
            }
        }
        [HttpGet]
        public ActionResult EditGivenJob(int id)
        {
            Session["jobId"] = id;
            JobsOffered job = new JobsOffered();
            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            var jobFound = dbObject.uspViewOneJob(id);

            foreach (var item in jobFound)
            {
                job.JobId = item.jobId;
                job.JobLocation = item.jobLocation;
                job.Experience = (int)item.experience;
                job.JobTitle = item.jobTitle;
                job.Qualification = item.qualification;

            }
            return View(job);


        }

        [HttpPost]
        public ActionResult EditGivenJob(JobsOffered job)
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter result = new ObjectParameter("res", typeof(Int32));
                int? exp = job.Experience;
                dbObject.uspUpdateJob(Convert.ToInt32(Session["jobId"]), job.JobTitle, job.JobLocation, job.Qualification, exp, result);
                var res = result.Value;
                if ((int)res > 0)
                {
                    MessageBox.Show("Job updated");
                    return RedirectToAction("ViewAllJobApplication");
                }
                else
                {
                    MessageBox.Show("Job details not Updated");
                    return RedirectToAction("ViewAllJobApplication");
                }
            }
            else
            {
                return View();
            }

        }


    }
}
﻿using OnlineRecruitmentSystem_Employer_.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace OnlineRecruitmentSystem_Employer_.Controllers
{
    public class GraduateController : Controller
    {
        //
        // GET: /Graduate/
        public ActionResult Index()
        {
            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            ObjectParameter userName = new ObjectParameter("uname", typeof(string));
            dbObject.uspGetUserName(Session["loginId"].ToString(), userName);

            Session["username"] = userName.Value;
            return View();
        }
        public ActionResult Logout()
        {
            if (Session["loginId"] == null)
            {
                MessageBox.Show("You are not logged in please login");
                return RedirectToAction("Index", "UserLogin");
            }
            else
            {
                Session.RemoveAll();
                return RedirectToAction("Index", "UserLogin");
            }
        }
        public ActionResult ViewAllJobsOffered()
        {

            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            var res = dbObject.uspViewAllJobsGraduate(Session["loginId"].ToString());
            List<JobsOffered> jobList = new List<JobsOffered>();
            foreach (var item in res)
            {
                JobsOffered job = new JobsOffered();
                job.JobId = item.JobId;
                job.JobTitle = item.Jobtitle;
                job.EmployerName = item.employername;
                job.Qualification = item.qualification;
                job.Experience = (int)item.experience;
                job.JobLocation = item.joblocation;
                jobList.Add(job);
            }

            return View(jobList);
        }



        [HttpGet]
        public ActionResult SavePassword()
        {
            return View();
        }
        [HttpPost]

        public ActionResult SavePassword(UserPassword pwd)
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter result = new ObjectParameter("res", typeof(string));
                dbObject.uspSavePassword(Session["loginId"].ToString(), pwd.Password, result);
                var res = result.Value.ToString();
                int finalResult = Convert.ToInt32(res);
                if (finalResult > 0)
                {
                    MessageBox.Show("Your Password has been saved");
                    return RedirectToAction("Index");
                }
                else
                {
                    MessageBox.Show("Your Password has not been saved");
                    return RedirectToAction("Index");
                }
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        [HttpGet]
        public ActionResult UpdateGraduateDetails()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UpdateGraduateDetails(GraduateDetails newGraduate)
        {
            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            ObjectParameter result = new ObjectParameter("res", typeof(Int32));
          
            dbObject.uspUpdateGraduateDetails(newGraduate.userName, newGraduate.degree, newGraduate.degreePercentage, newGraduate.tenthPercentage, newGraduate.intermediatePercentage, 
                newGraduate.technology,newGraduate.experience, newGraduate.preferredLocation, newGraduate.mobile, Session["loginId"].ToString(), result);
            var finalResult = result.Value;
            if ((int)finalResult > 0)
            {
                MessageBox.Show("Your details has been saved");
                return RedirectToAction("Index");
            }
            else
            {
                MessageBox.Show("Your details has not been saved");
                return RedirectToAction("Index");
            }


        }


        public ActionResult ViewGraduateDetails()
        {
            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            var res = dbObject.uspViewGraduateDetails(Session["loginId"].ToString());
            foreach (var item in res)
            {
                GraduateDetails emp = new GraduateDetails();
                emp.userName = item.applicantname;
                emp.mobile = item.mobile;
                emp.degree = item.degree;
                emp.degreePercentage = (decimal)item.degreePercentage;
                emp.intermediatePercentage = (decimal)item.intermediatePercentage;
                emp.tenthPercentage = (decimal)item.tenth;
                emp.technology = item.technology;
                emp.preferredLocation = item.preferredlocation;
                emp.experience = (int)item.experience;
                return View(emp);
            }

            MessageBox.Show("You have not saved your details Save your details");
            return RedirectToAction("SaveMyDetails");

        }
        [HttpGet]
        public ActionResult SaveMyDetails()
        {
            return View();
        }
        [HttpPost]
        public ActionResult SaveMyDetails(GraduateDetails emp)
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter result = new ObjectParameter("res", typeof(Int32));

                dbObject.uspSaveGraduatedetails(emp.userName, emp.degree, emp.degreePercentage, emp.tenthPercentage, emp.intermediatePercentage, emp.technology, emp.experience, emp.preferredLocation, emp.mobile, Session["loginId"].ToString(), result);
                var res = result.Value;
                if ((int)res > 0)
                {
                    MessageBox.Show("Your details has been saved");
                    return RedirectToAction("Index");

                }
                else
                {
                    MessageBox.Show("Details has not been saved");
                    return RedirectToAction("Index");
                }
            }
            else
            {
                return View();
            }
        }

        [HttpGet]
        public ActionResult ApplyNewJob()
        {
            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            var res = dbObject.uspViewAllJobsGraduate(Session["loginId"].ToString());
            List<JobsOffered> jobList = new List<JobsOffered>();
            foreach (var item in res)
            {
                JobsOffered job = new JobsOffered();
                job.JobId = item.JobId;
                job.JobTitle = item.Jobtitle;
                job.EmployerName = item.employername;
                job.Qualification = item.qualification;
                job.Experience = (int)item.experience;
                job.JobLocation = item.joblocation;

                jobList.Add(job);
            }

            return View(jobList);
        }

        public ActionResult ApplyTheSelectedJob(int id, string title)
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter appId = new ObjectParameter("appId", typeof(string));
                ObjectParameter result = new ObjectParameter("res", typeof(Int32));

                dbObject.uspApplyJob(id, title, appId, Session["loginId"].ToString(), result);

                var finalresult = result.Value;
                if ((int)finalresult > 0)
                {
                    MessageBox.Show("Your Application details has been saved");
                    return RedirectToAction("ViewMyApplication");
                }
                else
                {
                    MessageBox.Show("You have already applied for this job");
                    return RedirectToAction("ViewMyApplication");
                }
            }
            else
            {
                return View();
            }

        }




        [HttpPost]
        public ActionResult ApplyNewJob(int id, string title)
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter appId = new ObjectParameter("appId", typeof(string));
                ObjectParameter result = new ObjectParameter("res", typeof(Int32));

                dbObject.uspApplyJob(id, title, appId, Session["loginId"].ToString(), result);

                var finalresult = result.Value;
                if ((int)finalresult > 0)
                {
                    MessageBox.Show("Your Application details has been saved");
                    return RedirectToAction("Index");
                }
                else
                {
                    MessageBox.Show("You have already applied ");
                    return View();
                }
            }
            else
            {
                return View();
            }
        }




        [HttpGet]
        public ActionResult ViewMyApplication()
        {
            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            var job = dbObject.uspViewJobApplicationForms(Session["loginId"].ToString());

            List<JobApplication> appList = new List<JobApplication>();
            foreach (var item in job)
            {
                JobApplication jobApp = new JobApplication();
                jobApp.userName = item.applicantName;
                jobApp.degree = item.degree;
                jobApp.degreePercentage = (decimal)item.degreePercentage;
                jobApp.intermediatePercentage = (decimal)item.intermediatePercentage;
                jobApp.tenthPercentage = (decimal)item.tenthPercentage;
                jobApp.mobile = item.mobile;
                jobApp.preferredLocation = item.preferredLocation;
                jobApp.experience = (int)item.experience;
                jobApp.technology = item.technology;
                jobApp.applicantId = item.applicationId;
                jobApp.JobId = (int)item.jobId;
                jobApp.JobTitle = item.jobTitle;
                jobApp.ApplicationStatus = item.applicationStatus;
                appList.Add(jobApp);

            }
            TempData["appList"] = appList;

            if (appList.Count == 0)
            {
                MessageBox.Show("You Have not Applied!");
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("ViewAllApplication", new { job = appList });

            }
        }

        [HttpPost]
        public ActionResult ViewMyApplication(List<JobApplication> job)
        {
            if (ModelState.IsValid)
            {
                var jobList = TempData["appList"];
                if (jobList != null)
                    return View(jobList);
                else
                    MessageBox.Show("You Have not Applied!");
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }

        public ActionResult Delete(string id)
        {
            DialogResult dr = MessageBox.Show("Warning!! you are about to delete a application.\nAre you sure? ","Warning",MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter result = new ObjectParameter("res", typeof(Int32));
                var job = dbObject.uspDeleteApplication(id, result);
                var final = result.Value;
                if((int)final>0)
                {
                    MessageBox.Show("Application has been deleted");
                    return RedirectToAction("ViewAllApplication");
                }
                else
                {
                    MessageBox.Show("Application has not been deleted");
                    return RedirectToAction("ViewAllApplication");

                }

            }
            else
            {
                return RedirectToAction("ViewAllApplication");
            }
        }

        
        public ActionResult CheckStatus(string id)
        {
            if (ModelState.IsValid)
            {
                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                var job = dbObject.uspCheckApplicationStatus(id);
                JobApplication jobStatus = new JobApplication();
                foreach (var item in job)
                {
                    jobStatus.applicantId = item.applicationId;
                    jobStatus.JobTitle = item.jobTitle;
                    jobStatus.JobId = (int)item.jobId;
                    jobStatus.userName = item.applicantName;
                    jobStatus.ApplicationStatus = item.applicationStatus;
                }
                return View(jobStatus);
            }
            else
            {
                return View();
            }
        }


        [HttpGet]


        public ActionResult ViewAllApplication(List<JobApplication> job)
        {
            var list = TempData["appList"];

            return View(list);
        }

        [HttpGet]
        public ActionResult EditDetails()
        {
            OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
            var res = dbObject.uspViewGraduateDetails(Session["loginId"].ToString());
            foreach (var item in res)
            {
                GraduateDetails emp = new GraduateDetails();
                emp.userName = item.applicantname;
                emp.mobile = item.mobile;
                emp.degree = item.degree;
                emp.degreePercentage = (decimal)item.degreePercentage;
                emp.intermediatePercentage = (decimal)item.intermediatePercentage;
                emp.tenthPercentage = (decimal)item.tenth;
                emp.technology = item.technology;
                emp.preferredLocation = item.preferredlocation;
                emp.experience = (int)item.experience;
                return View(emp);
            }

            MessageBox.Show("You have not saved your details Save your details");
            return RedirectToAction("SaveMyDetails");
            


          
        }
        [HttpPost]
        public ActionResult EditDetails(GraduateDetails job)
        {
            if (ModelState.IsValid)
            {

                OnlineRecruitmentSystemEntities dbObject = new OnlineRecruitmentSystemEntities();
                ObjectParameter result = new ObjectParameter("res", typeof(Int32));
                //dbObject.uspUpdateGraduateDetails(Session["loginId"].ToString(), job.userName, job.degree, job.degreePercentage, job.intermediatePercentage, job.tenthPercentage, job.mobile, job.technology, job.preferredLocation, job.experience, result);

                dbObject.uspUpdateGraduateDetails(job.userName, job.degree, job.degreePercentage, job.tenthPercentage, job.intermediatePercentage, job.technology, job.experience, job.preferredLocation, job.mobile, Session["loginId"].ToString(), result);
                var res = result.Value;
                if ((int)res > 0)
                {
                    MessageBox.Show("Details Updated");
                    return RedirectToAction("ViewGraduateDetails");
                }
                else
                {
                    MessageBox.Show("Details Not Updated");
                    return View();
                }
            }
            else
            {
                return View();
            }
        }

    }
}
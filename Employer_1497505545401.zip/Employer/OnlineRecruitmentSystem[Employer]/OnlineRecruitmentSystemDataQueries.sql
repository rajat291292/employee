--Database Creation

Create database OnlineRecruitmentSystem
on Primary(
Name=OnlineRecruitmentSystemData,
filename='d:\CaseStudy2\Online Recruitment System\OnlineRecruitmentSystemData.mdf',
size=50mb,
maxsize=100mb,
filegrowth=10%)
Log on (Name=OnlineRecruitmentSystemLog,
filename='d:\CaseStudy2\Online Recruitment System\OnlineRecruitmentSystemData.ldf',
size=20mb,
maxsize=UNLIMITED,
filegrowth=10%)

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Create table tblTypesOfUser
(
userId int identity(1001,1) Primary Key,
userType varchar(50)
)


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Create table tblUserDetails
(
loginId varchar(10) Primary key,
userName varchar(max),
userId int,
gender varchar(10),  
mobile varchar(10),
pwd varchar(max)
foreign key(userId) references tblTypesOfUser(userId)

)


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Create table tblJobApplicationForm
(
applicationId varchar(35) Primary key,
applicantName varchar(max),
degree varchar(50),
degreePercentage decimal,
intermediatePercentage decimal,
tenthPercentage decimal,
technology varchar(max),
experience int,
preferredLocation varchar(max),
applicationStatus varchar(50),
loginId varchar(10),
foreign key(loginId) references tblUserDetails(loginId)
)

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Create table tblJobsOffered
(
jobTitle varchar(max),
jobLocation varchar(max),
qualification varchar(max),
experience int,
loginId varchar(10),
employerName varchar(max),
foreign key(loginId) references tblUserDetails(loginId)  
)

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create proc uspGetLoginId
@loginId varchar(10) out
As
Begin
declare @newid as int
if(exists(select * from tblUserDetails))
Begin 
select @newid =substring(MAX(loginId),5,3)+1 from tblUserDetails
if(@newid>=1 and @newid<=9)
set @loginId='User00'+Cast(@newid as varchar(5))
else if(@newId>=10 and @newId<=99)
set @loginId='User0'+cast(@newid as varchar(5))
else if(@newId>=100 and @newId<=999)
set @loginId='User'+cast(@newid as varchar(5))
end
else 
set @loginId='User001'
end

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create alter proc uspGetApplicantId
@loginId varchar(10) out
As
Begin
declare @newid as int
if(exists(select * from tblJobApplicationForm))
Begin 
select @newid =substring(MAX(applicationId),5,7)+1 from tblJobApplicationForm
if(@newid>=1 and @newid<=9)
set @loginId='JApp00'+Cast(@newid as varchar(5))
else if(@newId>=10 and @newId<=99)
set @loginId='JApp0'+cast(@newid as varchar(5))
else if(@newId>=100 and @newId<=999)
set @loginId='JApp'+cast(@newid as varchar(5))
end
else 
set @loginId='JApp001'
end

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create table tblUserCredentials
(
unum int identity (1,1) Primary key,
loginId varchar(10),
pwd varchar(max),
userId int,
foreign key(loginId) references tblUserDetails(loginId)  
)


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
create alter proc uspRegisterUser
@loginId varchar(max) out,
@name varchar(max),
@gender varchar(10),
@mobile varchar(10),
@usertype int,
@email varchar(max),
@res int out
as 
Begin 
execute uspGetLoginId @loginId out
Insert into tblUserDetails values(@loginId,@name,@usertype,@mobile,'',@gender,@email)
if(@@ROWCOUNT>0)
set @res=1
else
set @res=0
end


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create alter proc uspApplyForJob
@appId varchar(max) out,
@name varchar(max),
@degree varchar(max),
@degreePercentage decimal,
@intermediatePercentage decimal,
@tenthPercentage decimal,
@mobile varchar(10),
@technology varchar(max),
@preferredLocation varchar(max),
@experience int,
@loginId varchar(10),
@applicationStatus varchar(max),
@jobId int, 
@res int out
as 
Begin 
execute uspGetApplicantId @appId out
if exists( select * from tblJobApplicationForm)
set @res=0
else
Begin
Insert into tblJobApplicationForm values(@appId,@name,@degree,@degreePercentage,@intermediatePercentage,@tenthPercentage,@technology,@experience,@preferredLocation,@applicationStatus,@loginId,@jobId,@mobile)
if(@@ROWCOUNT>0)
set @res=1
end
end


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create proc uspAddNewJob
@jobTitle varchar(max),
@loginId varchar(10),
@employerName varchar(max),
@exp int,
@location varchar(max),
@qualification varchar(max),
@res int out 
as
Begin 
insert into tblJobsOffered values(@jobTitle,@location,@qualification,@exp,@loginId,@employerName)
if(@@ROWCOUNT>0)
set @res=1
else
set @res=0
end

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create alter proc uspCheckUser
@uname varchar(10),
@pwd varchar(max),
@uid int,
@res int out
as
Begin 
if exists (select * from tblUserCredentials where loginId=@uname and pwd=@pwd and  userId=@uid)
set @res=1
else
set @res=0
end

declare @res int 
execute uspCheckUser 'User001','moorthy','1001',@res out
print @res

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create proc uspSavePassword
@logId varchar(10),
@pwd varchar(max),
@res int out
as 
Begin 
update tblUserDetails set pwd=@pwd where loginId=@logId
if(@@ROWCOUNT>0)
set @res=1
else
set @res=0
end


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create  trigger updateCredentials on tblUserDetails
for Update as 
Begin
Insert into tblUserCredentials (loginId,pwd,userId)
select loginId,pwd,userId
from  tblUserDetails
end

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create proc uspGetUserName
@logId varchar(10),
@uname varchar(max) out
as 
begin
set @uname=(select userName from tblUserDetails where loginId=@logId)
end

declare @res int
exec uspCheckUser 'User001','moorthy','Admin',@res out
print @res


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create proc uspViewAllJobs
@logId varchar(10)
as
begin 
Select jobTitle,jobLocation,qualification,experience from tblJobsOffered where loginId=@logId
end

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
create proc uspUpdateJob
@logId varchar(10),
@jobTitle varchar(max),
@jobLocation varchar(max),
@qualification varchar(max),
@experience int ,
@res int out 
as 
Begin 
Update tblJobsOffered set jobTitle=@jobTitle,jobLocation=@jobLocation,qualification=@qualification,experience=@experience where loginId=@logId
if(@@ROWCOUNT>0)
set @res=1
else
set @res=0
end 

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


create proc uspViewOneJob 
@jobId int
as 
Begin 
Select * from tblJobsOffered where jobid=@jobId
end

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

alter table tblUserDetails
add email varchar(max)

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create proc uspDeleteJob
@jobid  int,
@res int out 
as 
Begin 
delete from tblJobsOffered
where jobId=@jobid
if(@@ROWCOUNT>0)
set @res=1
else
set @res=0
end

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
create proc uspViewUserDetails
as 
begin
SELECT DISTINCT dbo.tblUserDetails.userName, dbo.tblUserDetails.mobile, dbo.tblUserDetails.email,dbo.tblTypesOfUser.userType
FROM            dbo.tblUserCredentials INNER JOIN
dbo.tblUserDetails ON dbo.tblUserCredentials.loginId = dbo.tblUserDetails.loginId AND dbo.tblUserCredentials.loginId = dbo.tblUserDetails.loginId
Inner Join  tblTypesOfUser on dbo.tblUserDetails.userId=tblTypesOfUser.userId
end

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


create proc uspViewJobApp
@loginId varchar(10)
as 
begin 
select applicationId,applicantName,degree,degreepercentage,intermediatepercentage,tenthpercentage,mobile,technology,experience,preferredlocation 
from tblJobApplicationForm where loginid=@loginId
end

alter table tblJobApplicationForm 
add constraint uniqloginId
Unique(loginId)

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create alter proc uspSearchJobApplications 'Java'
@technology varchar(max),
@location varchar(max),
@exp int 
as 
Begin 
if(@technology!=null and @location!=null and @exp!=null)
select * from tblJobApplicationForm where preferredLocation=@location and  experience=@exp and technology=@technology
else if(@technology!=null and @location!=null)
select * from tblJobApplicationForm where preferredLocation=@location  and technology=@technology
else if(@technology!=null and @exp!=null)
select * from tblJobApplicationForm where preferredLocation=@location  and experience=@exp
else if(@exp!=null and  @location!=null)
select * from tblJobApplicationForm where preferredLocation=@location  and experience=@exp
else if(@exp!=null)
select * from tblJobApplicationForm where  experience=@exp
else if(@technology!=null)
select * from tblJobApplicationForm where  technology=@technology
else if (@location!=null)
select * from tblJobApplicationForm where preferredLocation=@location 
end


alter proc uspSearchJobApplications 'c#','HYD',1
@technology varchar(max),
@location varchar(max),
@exp int 
as 
Begin
declare @sqlQuery varchar(max)
set @sqlQuery='Select * from tblJobApplicationForm where (1=1)' 
if(@technology Is not null)
set @sqlQuery=@sqlQuery + 'and technology=@technology'
if(@exp Is not null)
set @sqlQuery=@sqlQuery + 'and experience=@exp'
if(@location is not null)
set @sqlQuery=@sqlQuery + 'and preferredLocation=@location'
Select * from tblJobApplicationForm where (technology is null or technology=@technology or technology like('%') )
and (preferredlocation is null or preferredLocation=@location or preferredLocation like ('%'))
and (experience is null or experience=@exp or experience like ('%'))
end


alter proc uspSearchJobApplications 
@technology varchar(max),
@location varchar(max),
@exp int ,
@criteria int
as 
begin 
if(@criteria=1)
Select * from tblJobApplicationForm where  technology=@technology
else if(@criteria=2)
Select * from tblJobApplicationForm where  preferredLocation=@location
else if (@criteria=3)
Select * from tblJobApplicationForm where  experience=@exp
else if (@criteria=4)
select * from tblJobApplicationForm where preferredLocation=@location and  experience=@exp and technology=@technology
end


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CREATE proc uspUpdateJobApplication
@loginId varchar(10),
@userName varchar(max),
@degree varchar(max),
@degreePercentage decimal,
@intermediatePercentage decimal,
@tenthPercentage  decimal,
@mobile varchar(10),
@technology varchar(max),
@preferredLocation varchar(max),
@experience int ,
@res int out 
as 
Begin 
Update tblJobApplicationForm set applicantName=@userName,degree=@degree,degreePercentage=@degreePercentage,intermediatePercentage=@intermediatePercentage,technology=@technology,tenthPercentage=@tenthPercentage,experience=@experience,preferredLocation=@preferredLocation,mobile=@mobile where loginId=@loginId
if(@@ROWCOUNT>0)
set @res=1
else
set @res=0
end 

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create alter proc uspViewAllJobApplicationForms 
@loginId varchar(10)
as 
begin
select * from tblJobApplicationForm where applicationStatus = 'Applied' and jobId in
(Select jobId from tblJobsOffered where loginId=@loginId)
end


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create proc uspUpdateApplication
@appid varchar(50),
@uname varchar(max),
@res int out
as 
Begin
declare @status varchar(max)
set @status = 'Application has been accepted by ' + @uname
Update tblJobApplicationForm set applicationStatus=@status where applicationId= @appid
if(@@ROWCOUNT>0)
set @res=1
else
set @res=0
end

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
alter table tblJobApplicationForm
add jobTitle varchar(max)

create alter proc uspApplyJob
@JobId int,
@JobTitle varchar(max),
@appId varchar(10) out,
@logId varchar(10),
@res int out
as 
Begin 
if exists(select  * from tblGraduateDetails where loginId = @logId)
set @res=1
begin
if exists(Select * from tblJobApplicationForm where loginId=@logId and jobId=@JobId)
set @res=2
end
if @res=1
begin
execute uspGetApplicantId @appId out
declare @applicantname varchar(max),@degree varchar(max),@degreePercentage decimal,
@tenthpercentage decimal,@intemediate decimal,@technology varchar(max),@exp int,@preferredlocation varchar(max),
@mobile varchar(10)
set @applicantname=(select applicantname from tblGraduateDetails where loginId=@logId)
set @degree=(select degree from tblGraduateDetails where loginId=@logId)
set @degreePercentage=(select degreepercentage from tblGraduateDetails where loginId=@logId)
set @intemediate=(select intermediatepercentage from tblGraduateDetails where loginId=@logId)
set @tenthpercentage=(select tenth from tblGraduateDetails where loginId=@logId)
set @preferredlocation=(select preferredlocation from tblGraduateDetails where loginId=@logId)
set @mobile=(select mobile from tblGraduateDetails where loginId=@logId)
set @exp=(select experience from tblGraduateDetails where loginId=@logId)
set @technology=(select technology from tblGraduateDetails where loginId=@logId)
Insert tblJobApplicationForm values(@appId,@applicantname,@degree,@degreePercentage,@intemediate,@tenthpercentage,@technology,@exp,@preferredlocation,'Applied',@logId,@JobId,@mobile,@JobTitle)
if(@@ROWCOUNT>0)
set @res=1
else
set @res=0
end 
else if @res=2
set @res=0
end

-----------------------------------------------------------------------------------------------------------------------------------------------------------

create proc uspUpdateGraduateDetails
@applicantname varchar(max),
@degree varchar(max),
@degreePercentage decimal,
@tenthpercentage decimal,
@intermediate decimal,
@technology varchar(max),
@exp int,
@preferredlocation varchar(max),
@mobile varchar(10),
@logId varchar(10),
@res int out
as 
Begin 
Insert  into tblGraduateDetails values(@applicantname ,@degree ,@degreePercentage ,
@intermediate ,@tenthpercentage,@technology ,@preferredlocation ,
@mobile,@exp ,@logId )
if(@@ROWCOUNT>0)
set @res=1
else
set @res=0
end

alter table tblGraduateDetails
add constraint UniqlogId
Unique(loginId)




-----------------------------------------------------------------------------------------------------------------------------------------------------------

create proc uspViewGraduateDetails
@logId varchar(10)
as 
Begin
Select applicantname ,degree ,degreePercentage ,intermediatePercentage ,tenth,technology ,preferredlocation ,mobile,experience from tblGraduateDetails where loginId=@logId
end

-----------------------------------------------------------------------------------------------------------------------------------------------------------


create alter proc uspSavedEmployerDetails
@Username varchar(max),
@dateofbirth varchar(max),
@gender varchar(max),
@mobile varchar(max),
@email varchar(max),
@loginId varchar(10),
@res int out
as 
begin 
Insert into tblEmployerDetails values(@Username,@dateofbirth,@gender,@mobile,@email,@loginId)
if(@@ROWCOUNT>0)
set @res=1
else
set @res=0
end

create proc uspUpdateEmployerDetails
@Username varchar(max),
@dateofbirth varchar(max),
@gender varchar(max),
@mobile varchar(max),
@email varchar(max),
@loginId varchar(10),
@res int out
as 
begin 
Update  tblEmployerDetails set usernameName=@Username,dateOfbirth=@dateofbirth,gender=@gender,mobile=@mobile,email=@email
where loginId=@loginId
if(@@ROWCOUNT>0)
set @res=1
else
set @res=0
end


Create proc uspViewEmployerdetails
@loginId varchar(10)
as 
begin
Select * from tblEmployerDetails where loginId=@loginId
end

create  proc uspViewAllJobsGraduate 'user008'
@loginId varchar(10)
as 
begin 
select JobId,Jobtitle,qualification,tblJobsoffered.experience,joblocation,employername from tblJobsOffered inner join tblGraduateDetails
on tblJobsOffered.jobLocation=tblGraduateDetails.preferredLocation  and 
tblJobsOffered.qualification=tblGraduateDetails.degree  and 
tblJobsOffered.experience=tblGraduateDetails.experience  and
tblGraduateDetails.loginId=(select loginId from tblUserDetails where loginId=@loginId and userId=1003 )
end


declare @res int

alter table tblJobApplicationForm
add constraint uniq_loginid
Unique(loginId)


sp_helptext uspViewJobApp 
CREATE  proc [dbo].[uspViewJobApplicationForms]

@loginId varchar(10)

as 

begin 

select *
from tblJobApplicationForm where loginid=@loginId

end

create proc uspCheckApplicationStatus
@appId varchar(30)
as 
begin 
select * from tblJobApplicationForm where applicationId=@appId
end 


create proc uspCancelApplication
@appId varchar(10),
@res int out
as
begin 
Update tblJobApplicationForm set applicationStatus='Cancelled' where applicationId=@appId
if(@@ROWCOUNT>0)
set @res=1
else
set @res=0
end

create proc uspDeleteApplication
@appId varchar(10),
@res int out
as 
begin
Delete from tblJobApplicationForm where applicationId= @appId 
if(@@ROWCOUNT>0)
set @res=1
else
set @res=0
end

create proc uspDeleteUser 'User010'
@logId varchar(10),
@res int out
as 
begin 
delete from tblUserCredentials where loginId=@logId
if(@@ROWCOUNT>0)
set @res=1
else
set @res=0
end


declare @res int
execute uspDeleteUser 'User010',@res out
print @res

sp_helptext uspviewuserdetails


create alter proc uspViewAllUserDetails

as 

begin

SELECT DISTINCT  dbo.tblUserDetails.loginId, dbo.tblUserDetails.userName, dbo.tblUserDetails.mobile, dbo.tblUserDetails.email,dbo.tblTypesOfUser.userType

FROM            dbo.tblUserCredentials INNER JOIN

dbo.tblUserDetails ON dbo.tblUserCredentials.loginId = dbo.tblUserDetails.loginId AND dbo.tblUserCredentials.loginId = dbo.tblUserDetails.loginId

Inner Join  tblTypesOfUser on dbo.tblUserDetails.userId=tblTypesOfUser.userId and tblTypesOfUser.userId !=1001

end



declare @res int
exec  uspCheckUser 'User015','vishnu',1003,@res out
print @res

Select * from tblUserCredentials where loginId='USer015' and pwd = 'vishnu' and userid=1003

declare @res int
execute uspUpdateJobApplication 'User015','Gautham','BE',80,80,80,'8996969685','DotNet','Bangalore',1,@res out
print @res



sp_helptext uspSearchJobApplications

CREATE alter proc uspSearchJobApplications 

@technology varchar(max),

@location varchar(max),

@exp int ,

@criteria int,

@loginId varchar(10)

as 

begin 
declare @jobid int
set @jobid=(select jobId from tblJobsOffered where loginId=@loginId)
if(@criteria=1)

Select * from tblJobApplicationForm where  technology=@technology and jobId=@jobid

else if(@criteria=2)

Select * from tblJobApplicationForm where  preferredLocation=@location and jobId=@jobid

else if (@criteria=3)

Select * from tblJobApplicationForm where  experience=@exp and jobId=@jobid

else if (@criteria=4)

select * from tblJobApplicationForm where preferredLocation=@location and  experience=@exp and technology=@technology and jobId=@jobid

end


